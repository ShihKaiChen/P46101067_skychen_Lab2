import pygame
import time

#基本設定
screen_width=1024
screen_height=600
BTN_width = 80
BTN_height = 80
HP_width = 40
HP_height = 40
FPS=30


# color (RGB)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)

#載入圖片
background = pygame.transform.scale(pygame.image.load("images/Map.png"), (screen_width, screen_height))
enemy=pygame.transform.scale(pygame.image.load('images/enemy.png'),(BTN_width,BTN_height))
hp=pygame.transform.scale(pygame.image.load('images/hp.png'),(HP_width,HP_height))
hp_gray=pygame.transform.scale(pygame.image.load('images/hp_gray.png'),(HP_width,HP_height))
btn_continue=pygame.transform.scale(pygame.image.load('images/continue.png'),(BTN_width,BTN_height))
btn_muse=pygame.transform.scale(pygame.image.load('images/muse.png'),(BTN_width,BTN_height))
btn_sound=pygame.transform.scale(pygame.image.load('images/sound.png'),(BTN_width,BTN_height))
btn_pause=pygame.transform.scale(pygame.image.load('images/pause.png'),(BTN_width,BTN_height))

#初始化
pygame.init()
#建立視窗
screen=pygame.display.set_mode((screen_width,screen_height))
#設立遊戲標題
pygame.display.set_caption('My First Game')
#設定時間
clock=pygame.time.Clock()
#記錄開始的時間
start_time=time.time()


pygame.init()
#設定文字大小
font=pygame.font.Font(None,25)

class Game:
    def __init__(self):
        # window
        #將圖片輸入到Game
        self.background=background
        self.enemy=enemy
        self.hp_pic=hp
        self.hp_gray_pic=hp_gray
        self.btn_continue=btn_continue
        self.btn_muse=btn_muse
        self.btn_sound=btn_sound
        self.btn_pause=btn_pause

        # hp
        #設定灰色的血量等於最大血量減掉剩餘血量
        self.hp = 7
        self.max_hp = 10
        self.gray_hp=self.max_hp-self.hp
        #宣告開始時間及字型大小
        self.start_time=start_time
        self.font=font
        

    def game_run(self):
        #pygame.init()
        # game loop
        run = True
        while run:
            clock.tick(FPS)
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    run=False
                

            # draw background
            screen.blit(background,(0,0))

            # draw enemy and health bar
            screen.blit(enemy,(100,400))
            pygame.draw.rect(screen, RED, [115, 395, 50, 8])

            # draw menu (and buttons)
            pygame.draw.rect(screen,BLACK,[0,0,1024,90])
            #設定迴圈，使得上方標示會隨著血量而改變
            for i in range(0,self.hp) :
                screen.blit(self.hp_pic,(400+(i%5)*HP_width,(i//5)*HP_height))
            for i in range(0,self.gray_hp) :
                screen.blit(self.hp_gray_pic,((560-(i%5)*HP_width),((9-i)//5)*HP_height))
            #設定按鍵位置
            screen.blit(btn_muse,(680,10))
            screen.blit(btn_sound,(760,10))
            screen.blit(btn_continue,(840,10))
            screen.blit(btn_pause,(920,10))


            # draw time(bonus)
            #用目前時間減掉開始時間即可計時
            game_time=int(time.time()-self.start_time)
            #將時間化成分秒
            game_second=int((game_time%60))
            game_minute=int((game_time/60)%60)
            #在左下方畫一個放置數字的黑底
            pygame.draw.rect(screen,BLACK,[0,570,50,30])
            #設定文字顏色並將分秒補0到兩位數，將數字改成指定字串
            time_text=self.font.render(str(game_minute)+':'+str(game_second).zfill(2),True,WHITE)
            screen.blit(time_text,(10,575))

            pygame.display.update()

if __name__ == "__main__":
    covid_game = Game()
    covid_game.game_run()